﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace WebApplication4.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }

        [Required(ErrorMessage="can not be empty")]
        [Display (Name="name")]
        public string cname { get; set; }

        [Required(ErrorMessage = "can not be empty")]
        [Display(Name = "address")]
        public string caddress { get; set; }
       
        [Required(ErrorMessage = "can not be empty")]
        [Display(Name = "email")]
        public string cemail { get; set; }
       
        [Required(ErrorMessage = "can not be empty")]
        [Display(Name = "username")]
        public string cusername { get; set; }
       
        [Required(ErrorMessage = "can not be empty")]
        [Display(Name = "password")]
        public string cpassword { get; set; }
    }
}